if (window.location.href.includes("ana.html")) {
  const langEl = document.getElementById("lang");
  const autoEl = document.getElementById("auto");
  const animEl = document.getElementById("animation");
  const statusEl = document.getElementById("status");
  const saveBtn = document.getElementById("save");

  chrome.storage.local.get(["targetLang", "autoDetect", "animation"], (data) => {
    langEl.value = data.targetLang || "tr";
    autoEl.checked = data.autoDetect || false;
    animEl.value = data.animation || "fade";
  });

  saveBtn.onclick = () => {
    chrome.storage.local.set({
      targetLang: langEl.value,
      autoDetect: autoEl.checked,
      animation: animEl.value
    }, () => {
      statusEl.textContent = "✅ Ayarlar kaydedildi!";
      setTimeout(() => (statusEl.textContent = ""), 2000);
    });
  };
}
