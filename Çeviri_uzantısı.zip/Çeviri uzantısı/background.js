chrome.runtime.onInstalled.addListener(details => {
  if (details.reason === "install") {
    chrome.runtime.openOptionsPage();
  }

  chrome.contextMenus.create({
    id: "translate",
    title: "Çevir",
    contexts: ["selection"]
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const selectedText = info.selectionText;

  chrome.storage.local.get(["targetLang", "autoDetect", "animation"], async (data) => {
    let lang = data.targetLang || "tr";
    const animation = data.animation || "fade";

    if (data.autoDetect) {
      try {
        const res = await fetch("https://ipapi.co/json/");
        const json = await res.json();
        lang = json.languages?.split(",")[0] || lang;
      } catch (e) {
        console.warn("IP dil algılama başarısız:", e);
      }
    }

    const maxChars = 700;
    let textToTranslate = selectedText;
    let showWarning = false;

    if (selectedText.length > maxChars) {
      textToTranslate = selectedText.slice(0, maxChars);
      showWarning = true;
    }

    const translate = await fetch(
      `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${lang}&dt=t&q=${encodeURIComponent(textToTranslate)}`
    );
    const result = await translate.json();
    let translated = result[0].map(item => item[0]).join(" ");

    if (showWarning) {
      translated += "\n\n⚠️ Maksimum 700 karakter çevrilebilir!";
    }

    const wordCount = selectedText.trim().split(/\s+/).length;
    let duration = Math.min(15000, Math.max(3000, wordCount * 2000));

    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: (text, duration, animation) => {
        const oldContainer = document.getElementById("erdem-translate-container");
        if (oldContainer) oldContainer.remove();

        const container = document.createElement("div");
        container.id = "translate-container";
        Object.assign(container.style, {
          position: "fixed",
          bottom: "20px",
          right: "20px",
          zIndex: 999999,
          userSelect: "none",
          pointerEvents: "auto",
          opacity: "0",
          transformOrigin: "center",
          transition: "opacity 0.4s ease, transform 0.4s ease"
        });

        const popup = document.createElement("div");
        popup.id = "translate-popup";
        popup.textContent = text;

        const charCount = text.length;
        const maxWidth = 320;
        const maxFontSize = 16;
        const minFontSize = 10;

        let fontSize;
        if (charCount <= 250) {
          fontSize = maxFontSize;
        } else {
          const excess = charCount - 250;
          const maxExcess = 450;
          const scale = Math.min(excess / maxExcess, 1);
          fontSize = maxFontSize - scale * (maxFontSize - minFontSize);
          fontSize = Math.max(fontSize, minFontSize);
        }

        Object.assign(popup.style, {
          background: "#222",
          color: "white",
          padding: "14px 18px",
          borderRadius: "12px",
          fontSize: fontSize + "px",
          maxWidth: maxWidth + "px",
          boxShadow: "0 0 20px rgba(0,0,0,0.7)",
          userSelect: "text",
          cursor: "default",
          wordBreak: "break-word",
          overflowWrap: "break-word",
          whiteSpace: "pre-wrap"
        });

        const closeBtn = document.createElement("button");
        closeBtn.textContent = "✕";
        Object.assign(closeBtn.style, {
          position: "absolute",
          top: "-12px",
          right: "-12px",
          background: "#ff5555",
          border: "none",
          borderRadius: "50%",
          width: "28px",
          height: "28px",
          color: "white",
          fontWeight: "bold",
          fontSize: "18px",
          cursor: "pointer",
          boxShadow: "0 0 8px rgba(255, 0, 0, 0.7)",
          userSelect: "none",
          zIndex: "1000000",
          lineHeight: "28px",
          textAlign: "center",
          padding: "0"
        });
        closeBtn.onclick = () => {
          container.style.opacity = "0";
          container.style.transform = "translateY(20px)";
          setTimeout(() => container.remove(), 400);
        };

        container.appendChild(popup);
        container.appendChild(closeBtn);
        document.body.appendChild(container);

        switch(animation) {
          case "fade":
            container.style.transform = "translateY(20px)";
            break;
          case "slide":
            container.style.transform = "translateX(100%)";
            break;
          case "zoom":
            container.style.transform = "scale(0.5)";
            break;
          case "flip":
            container.style.transform = "rotateY(90deg)";
            break;
          default:
            container.style.transform = "translateY(20px)";
        }

        setTimeout(() => {
          container.style.opacity = "1";
          container.style.transform = "none";
        }, 50);

        setTimeout(() => {
          container.style.opacity = "0";
          switch(animation) {
            case "fade":
              container.style.transform = "translateY(20px)";
              break;
            case "slide":
              container.style.transform = "translateX(100%)";
              break;
            case "zoom":
              container.style.transform = "scale(0.5)";
              break;
            case "flip":
              container.style.transform = "rotateY(90deg)";
              break;
            default:
              container.style.transform = "translateY(20px)";
          }
          setTimeout(() => container.remove(), 400);
        }, duration);
      },
      args: [translated, duration, animation]
    });
  });
});
